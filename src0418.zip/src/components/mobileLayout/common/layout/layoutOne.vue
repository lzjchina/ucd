<template>
  <div class="globaHeard">
    <div>全局头部</div>
    <router-view />
  </div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<style lang="stylus">
.globaHeard
  width 100vw
  max-width 100%
  height 128px
  
</style>

<template>
  <div>
    <div>个人详情页侧栏</div>
    <router-view />
  </div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<style>
</style>

<template>
  <div class="Allorder-box">
     <table border="0" cellspacing="0" cellpadding="0" class="item">
        <tr>
          <td class="order-td1"></td>
          <td class="order-td2">
              <table border="0" cellspacing="0" cellpadding="0" style="border-bottom:1px solid #e5e5e5">
                <tr>
                  <td class="title-td1">
                    <span class="item1-title1">Created At: </span><span class="item1-data">2018/03/08 05:39:00</span>
                  </td>
                  <td class="title-td2">
                    <span class="item1-title1">Order ID: </span><span class="item1-data">100001600000003</span>
                  </td>
                  <td class="title-td3">
                        <img src="statics/images/Myorder/online.png" style="display: inline-block; vertical-align: middle; width: 20px; height: 20px; margin-right:4px " ><span class="item1-data">Online</span>
                  </td>
                  <td class="title-td4">
                    <img src="statics/images/Myorder/ico_del.png" style="display: inline-block; vertical-align: middle; width: 20px; height: 20px; margin-right:4px "><span class="item1-delete">Cancel</span>
                  </td>
                </tr>
              </table>
          </td>
          <td class="order-td1"></td>
        </tr>
        <tr>
          <td class="order-td1"></td>
          <td class="order-td2">
            <table class="bodyTable" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td>
                  <table border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td class="products-td1">
                           <img src="statics/images/Myorder/pic1.png" style="display: inline-block; vertical-align: middle; width: 80px; height: 80px ">     
                        </td>
                        <td class="products-td2">
                            <span class="item2-name">Apple iPhone X + 198 Bundle</span><br>
                            <span class="item2-data">Memory: 256 GB</span><br>
                            <span class="item2-data">Primary: 198 Bundle</span><br>
                            <span class="item2-data">Color: Space gray</span>
                        </td>
                        <td class="products-td3">
                            <span class="item2-Upfront">Upfront Price</span><br>
                            <span class="item2-price">$1149.00</span>
                        </td>
                        <td class="products-td4">
                            <span class="item2-Upfront">Monthly Fee</span><br>
                            <span class="item2-price">$198.00</span>
                        </td>
                        <td class="products-td5">
                            <span class="item2-Number">× 1</span>
                        </td>
                      </tr>
                  </table>
                  <table border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td class="products-td1">
                           <img src="statics/images/Myorder/pic2.png" style="display: inline-block; vertical-align: middle; width: 80px; height: 80px ">     
                        </td>
                        <td class="products-td2">
                            <span class="item2-name">Apple iPhone X + 198 Bundle</span><br>
                            <span class="item2-data">Memory: 256 GB</span><br>
                            <span class="item2-data">Primary: 198 Bundle</span><br>
                            <span class="item2-data">Color: Space gray</span>
                        </td>
                        <td class="products-td3">
                            <span class="item2-Upfront">Upfront Price</span><br>
                            <span class="item2-price">$1149.00</span>
                        </td>
                        <td class="products-td4">
                            <span class="item2-Upfront">Monthly Fee</span><br>
                            <span class="item2-price">$198.00</span>
                        </td>
                        <td class="products-td5">
                            <span class="item2-Number">× 1</span>
                        </td>
                      </tr>
                  </table>
                  <table border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td class="products-td1">
                           <img src="statics/images/Myorder/pic3.png" style="display: inline-block; vertical-align: middle; width: 80px; height: 80px ">     
                        </td>
                        <td class="products-td2">
                            <span class="item2-name">Apple iPhone X + 198 Bundle</span><br>
                            <span class="item2-data">Memory: 256 GB</span><br>
                            <span class="item2-data">Primary: 198 Bundle</span><br>
                            <span class="item2-data">Color: Space gray</span>
                        </td>
                        <td class="products-td3">
                            <span class="item2-Upfront">Upfront Price</span><br>
                            <span class="item2-price">$1149.00</span>
                        </td>
                        <td class="products-td4">
                            <span class="item2-Upfront">Monthly Fee</span><br>
                            <span class="item2-price">$198.00</span>
                        </td>
                        <td class="products-td5">
                            <span class="item2-Number">× 1</span>
                        </td>
                      </tr>
                  </table>
                </td>
                <td class="products-td6">
                  <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td style="width:calc(60/1920*100vw)"></td>
                      <td style="width:102px">
                        <span class="total-price-text">Upfront Price</span><br>
                        <span class="total-price-price">$1149.00</span>
                      </td>
                      <td style="width:calc(60/1920*100vw)"></td>
                    </tr>
                  </table>
                </td>
                <td class="products-td7">
                  <span class="third-payment-text">Waiting for payment</span><br>
                  <q-btn class="third-payment-btn">Pay Now</q-btn><br>
                  <span class="third-payment-view">view</span>
                </td>
              </tr>
            </table>
          </td>
          <td class="order-td1"></td>
        </tr>
     </table>
     <table border="0" cellspacing="0" cellpadding="0" class="item">
        <tr>
          <td class="order-td1"></td>
          <td class="order-td2">
              <table border="0" cellspacing="0" cellpadding="0" style="border-bottom:1px solid #e5e5e5">
                <tr>
                  <td class="title-td1">
                    <span class="item1-title1">Created At: </span><span class="item1-data">2018/03/08 05:39:00</span>
                  </td>
                  <td class="title-td2">
                    <span class="item1-title1">Order ID: </span><span class="item1-data">100001600000003</span>
                  </td>
                  <td class="title-td3">
                        <img src="statics/images/Myorder/online.png" style="display: inline-block; vertical-align: middle; width: 20px; height: 20px; margin-right:4px " ><span class="item1-data">Online</span>
                  </td>
                  <td class="title-td4">
                    <img src="statics/images/Myorder/ico_del.png" style="display: inline-block; vertical-align: middle; width: 20px; height: 20px; margin-right:4px "><span class="item1-delete">Cancel</span>
                  </td>
                </tr>
              </table>
          </td>
          <td class="order-td1"></td>
        </tr>
        <tr>
          <td class="order-td1"></td>
          <td class="order-td2">
            <table border="0" cellspacing="0" cellpadding="0" class="bodyTable">
              <tr>
                <td>
                  <table border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td class="products-td1">
                           <img src="statics/images/Myorder/pic1.png" style="display: inline-block; vertical-align: middle; width: 80px; height: 80px ">     
                        </td>
                        <td class="products-td2">
                            <span class="item2-name">Apple iPhone X + 198 Bundle</span><br>
                            <span class="item2-data">Memory: 256 GB</span><br>
                            <span class="item2-data">Primary: 198 Bundle</span><br>
                            <span class="item2-data">Color: Space gray</span>
                        </td>
                        <td class="products-td3">
                            <span class="item2-Upfront">Upfront Price</span><br>
                            <span class="item2-price">$1149.00</span>
                        </td>
                        <td class="products-td4">
                            <span class="item2-Upfront">Monthly Fee</span><br>
                            <span class="item2-price">$198.00</span>
                        </td>
                        <td class="products-td5">
                            <span class="item2-Number">× 1</span>
                        </td>
                      </tr>
                  </table>
                  <table border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td class="products-td1">
                           <img src="statics/images/Myorder/pic2.png" style="display: inline-block; vertical-align: middle; width: 80px; height: 80px ">     
                        </td>
                        <td class="products-td2">
                            <span class="item2-name">Apple iPhone X + 198 Bundle</span><br>
                            <span class="item2-data">Memory: 256 GB</span><br>
                            <span class="item2-data">Primary: 198 Bundle</span><br>
                            <span class="item2-data">Color: Space gray</span>
                        </td>
                        <td class="products-td3">
                            <span class="item2-Upfront">Upfront Price</span><br>
                            <span class="item2-price">$1149.00</span>
                        </td>
                        <td class="products-td4">
                            <span class="item2-Upfront">Monthly Fee</span><br>
                            <span class="item2-price">$198.00</span>
                        </td>
                        <td class="products-td5">
                            <span class="item2-Number">× 1</span>
                        </td>
                      </tr>
                  </table>
                </td>
                <td class="products-td6">
                  <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td style="width:calc(60/1920*100vw)"></td>
                      <td style="width:102px">
                        <span class="total-price-text">Upfront Price</span><br>
                        <span class="total-price-price">$1149.00</span>
                      </td>
                      <td style="width:calc(60/1920*100vw)"></td>
                    </tr>
                  </table>
                </td>
                <td class="products-td7">
                  <div class="third-payment">
                    <span class="third-payment-text2">The order has been cancelled</span><br>
                    <span class="third-payment-view2">view</span>
                  </div>
                </td>
              </tr>
            </table>
          </td>
          <td class="order-td1"></td>
        </tr>
     </table>
  </div>
</template>

<script>
import {
  QLayout,
  QTabs,
  QRouteTab,
  QSearch,
  QBtn
} from 'quasar'
export default {
  components: {
    QLayout,
    QTabs,
    QRouteTab,
    QSearch,
    QBtn
  }
}
</script>
<style lang="stylus">
.Allorder-box
  display flex
  justify-content center
  flex-direction column
  width calc(1516/1920*100vw)
  padding 0 0 0 2%
  font-family HelveticaNeue !important
  .bodyTable>tr:last-child>td>table:last-child>tr>td
    border none
  .item
    display flex
    justify-content center
    flex-direction column
    border 1px solid #e5e5e5
    margin-bottom 16px
    .order-td1
      width 32px
    .order-td2
      width calc(1472/1920*100vw)
      height 46px
      .title-td1
        width 272px
        text-align left
        height 46px
      .title-td2
        width 240px
        text-align left
      .title-td3
        width 200px
        text-align left
      .title-td4
        width calc(760/1920*100vw)
        text-align right
      .products-td1
        width 96px
        height 112px
      .products-td2
        width calc(385/1920*100vw)
        line-height 1
        border-bottom 1px solid #e5e5e5
      .products-td3
        width 110px
        text-align right
        border-bottom 1px solid #e5e5e5
      .products-td4
        width calc(198/1920*100vw)
        min-width 110px
        text-align right
        border-bottom 1px solid #e5e5e5
      .products-td5
        width calc(158/1920*100vw)
        min-width 96px
        text-align right
        border-bottom 1px solid #e5e5e5
      .products-td6
        text-align left
        width calc(222/1920*100vw)
        border-left 1px solid #e5e5e5
        border-right 1px solid #e5e5e5
        line-height 1.6
      .products-td7
        text-align center
        width calc(304/1920*100vw)
        line-height 1.6
  .item1
    display flex
    justify-content flex-start
    align-items stretch
    min-height 20px
    line-height 20px
    margin-top calc(16/1920*100vw)
    margin-bottom calc(16/1920*100vw)
    width 94%
  .item1-left
    min-width 200px
  .item1-title1
    color #b2b2b2
    font-size calc(14/1920*100vw)
    min-height 20px
  .item1-data
    color #666666
    font-size calc(14/1920*100vw)
    margin-right calc(56/1920*100vw)
    min-height 20px
  .item1-delete
    color #6abcfc
    font-size calc(14/1920*100vw)
  .item1-cancel
    min-width 70px
  .item1-online
    min-width 100px
    width calc(890/1920*100vw)
  .item1-hr
    display flex
    justify-content flex-start
    background #e5e5e5
    height 1px
    width 94%
    margin-left 3%
  .item2
    display flex
    justify-content flex-start
    min-height 20px
    line-height 0.8
    width 94%
    margin-left 3%
  .first-table-td
    display flex
    justify-content flex-start
    align-items center
    flex-direction column
    min-height 20px
    line-height 0.8
    width 62%
    border-right: 1px solid #e5e5e5;
  .item-product
    display flex
    justify-content flex-start
    align-items center
    min-height 20px
    line-height 0.8
    width 100%
  .item-font
    display flex
    justify-content flex-start
    align-items center
    min-height 20px
    line-height 0.8
    margin-top calc(16/1920*100vw)
    margin-bottom calc(16/1920*100vw)
    width 100%
    padding-bottom calc(20/1920*100vw)
    border-bottom 1px solid #e5e5e5
  .item2-img
    width 7%
    min-width 84px
    padding-bottom calc(18/1920*100vw)
  .item2-text
    width 48%
    min-width 130px
    line-height 1
  .item2-name
    font-size 14px
    font-weight bold
    color #252525
    line-height 1.4
  .item2-data
    font-size 12px
    color #666666
    line-height 1
  .item2-text2
    width 13%
    min-width 86px 
    line-height 1
    text-align right
  .item2-Upfront
    font-size 14px
    font-weight bold
    color #666666
    white-space nowrap
  .item2-price
    font-size 12px
    color #252525
    font-weight bold
  .item2-text3
    width 22%
    min-width 86px 
    line-height 1
    text-align right
    padding-right calc(20/1920*100vw)
  .item2-text4
    width 16%
    min-width 46px 
    line-height 1
    text-align center
  .item2-Number
    font-size 14px
    color #252525
    font-weight bold
    margin-right 40px
  .second-table-td
    display flex
    justify-content center
    align-items center
    min-height 100%
    line-height 1.4
    width 15%
    border-right 1px solid #e4e4e4
  .test
    border-right 1px solid red
    width 0px
    height 100%
    flex 0
  .total-price-text
    font-size 14px
    color #666666
    font-weight bold
  .total-price-price
    font-size 24px
    color #252525
    font-weight bold
  .third-table-td
    display flex
    justify-content center
    align-items center
    min-height 100px
    line-height 1.4
    width 24%
    text-align center
  .third-payment
    padding-bottom calc(18/1920*100vw)
  .third-payment-text
    font-size calc(14/1920*100vw)
    color #666666
    line-height 4
  .third-payment-view
    font-size calc(14/1920*100vw)
    color #6abcfc
    line-height 4
  .third-payment-view2
    font-size calc(14/1920*100vw)
    color #6abcfc
    line-height 3
  .third-payment-btn
    background #6dd6a9
    color #fff
    width calc(180/1920*100vw)
    min-width 72px
    min-height 24px
    height calc(32/1920*100vw)
    font-size calc(14/1920*100vw)
    border-radius 50px
    box-shadow 0 0 0 white
  .third-payment-text2
    font-size calc(14/1920*100vw)
    color #666666
    line-height 3
</style>


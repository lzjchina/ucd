export default {
  view: 'hhh lpr fff',
  reveal: true,
  leftScroll: false,
  rightScroll: false,
  leftBreakpoint: 996,
  rightBreakpoint: 0,
  hideTabs: true
}

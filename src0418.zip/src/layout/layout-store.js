export default {
  view: 'hHh lpr fFf',
  reveal: false,
  leftScroll: true,
  rightScroll: true,
  leftBreakpoint: 996,
  rightBreakpoint: 1200,
  hideTabs: false
}
